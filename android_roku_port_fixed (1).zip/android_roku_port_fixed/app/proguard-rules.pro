# Retrofit
-keepattributes Signature
-keepattributes *Annotation*
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}
# Gson / Models
-keep class com.syntra.rokuport.model.** { *; }
# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
# ExoPlayer / Media3
-keep class androidx.media3.** { *; }
