package com.syntra.rokuport.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    // ============================================================
    // CONFIGURE AQUI a URL do seu painel IPTV (com barra no final)
    // Exemplo: "https://seudominio.com/"  ou  "http://IP:PORTA/"
    // ============================================================
    const val API_BASE = "https://seuip-ou-url/"

    private val httpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    val service: RokuApi by lazy {
        Retrofit.Builder()
            .baseUrl(API_BASE)
            .client(httpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(RokuApi::class.java)
    }

    /** Recria o service com uma nova base URL (para multi-servidor) */
    fun serviceFor(baseUrl: String): RokuApi {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(httpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(RokuApi::class.java)
    }
}
