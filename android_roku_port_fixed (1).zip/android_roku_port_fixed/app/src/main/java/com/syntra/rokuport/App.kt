package com.syntra.rokuport

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
