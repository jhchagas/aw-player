package com.syntra.rokuport.api

import com.syntra.rokuport.model.*
import retrofit2.Response
import retrofit2.http.*

interface RokuApi {
    // ── Autenticação ─────────────────────────────────────────
    @POST("api/roku/register.php")
    suspend fun register(@Body body: RegisterRequest): Response<ApiResponse>

    @POST("api/roku/check-activation.php")
    suspend fun check(@Body body: CheckRequest): Response<ApiResponse>

    @POST("api/roku/login.php")
    suspend fun login(@Body body: LoginRequest): Response<ApiResponse>

    // ── Home ─────────────────────────────────────────────────
    @GET("api/roku/home.php")
    suspend fun home(@Query("token") token: String): Response<ApiResponse>

    // ── TV ao Vivo ───────────────────────────────────────────
    @GET("api/roku/live-categories.php")
    suspend fun liveCategories(@Query("token") token: String): Response<ApiResponse>

    @GET("api/roku/live-streams.php")
    suspend fun liveStreams(
        @Query("token") token: String,
        @Query("category_id") categoryId: String
    ): Response<ApiResponse>

    @GET("api/roku/play.php")
    suspend fun playLive(
        @Query("token") token: String,
        @Query("type") type: String = "live",
        @Query("id") id: String,
        @Query("ext") ext: String = "m3u8"
    ): Response<ApiResponse>

    // ── Filmes (VOD) ─────────────────────────────────────────
    @GET("api/roku/vod-categories.php")
    suspend fun vodCategories(@Query("token") token: String): Response<ApiResponse>

    @GET("api/roku/vod-movies.php")
    suspend fun vodMovies(
        @Query("token") token: String,
        @Query("category_id") categoryId: String
    ): Response<ApiResponse>

    @GET("api/roku/vod-play.php")
    suspend fun vodPlay(
        @Query("token") token: String,
        @Query("id") id: String
    ): Response<ApiResponse>

    // ── Séries ────────────────────────────────────────────────
    @GET("api/roku/series-categories.php")
    suspend fun seriesCategories(@Query("token") token: String): Response<ApiResponse>

    @GET("api/roku/series-list.php")
    suspend fun seriesList(
        @Query("token") token: String,
        @Query("category_id") categoryId: String
    ): Response<ApiResponse>

    @GET("api/roku/series-play.php")
    suspend fun seriesPlay(
        @Query("token") token: String,
        @Query("episode_id") episodeId: String
    ): Response<ApiResponse>
}
