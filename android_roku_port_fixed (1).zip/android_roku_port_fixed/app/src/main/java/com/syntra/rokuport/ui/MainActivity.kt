package com.syntra.rokuport.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.widget.*
import com.syntra.rokuport.R
import com.syntra.rokuport.api.ApiClient
import com.syntra.rokuport.model.*
import kotlinx.coroutines.*

class MainActivity : Activity() {

    private val scope = MainScope()
    private lateinit var deviceId: String
    private var token: String = ""
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var scrollView: ScrollView

    // Controla a pilha de navegação para voltar com o controle remoto
    private val navStack = ArrayDeque<() -> Unit>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            ?: "android-tv-${System.currentTimeMillis()}"
        token = getPreferences(MODE_PRIVATE).getString("token", "") ?: ""
        buildUi()
        if (token.isBlank()) showLogin() else showHome()
    }

    private fun buildUi() {
        val root = FrameLayout(this)

        // Background
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.aw_bg_default)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.3f
        }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        // Column
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(80, 40, 80, 40)
        }

        // Logo
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
        }
        column.addView(logo, LinearLayout.LayoutParams(280, 90))

        // Status
        status = TextView(this).apply {
            textSize = 20f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, 16, 0, 16)
            text = "AW Player"
        }
        column.addView(status)

        // Scrollable list
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scrollView = ScrollView(this).apply { addView(list) }
        column.addView(scrollView, LinearLayout.LayoutParams(-1, -1))

        root.addView(column)
        setContentView(root)
    }

    // ── Telas ────────────────────────────────────────────────────────────────

    private fun showLogin() {
        navStack.clear()
        list.removeAllViews()
        status.text = "Faça login para continuar"

        val provider = edit("Código do Provedor")
        val user = edit("Usuário")
        val pass = edit("Senha").apply { inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val btn = button("ENTRAR")

        list.addView(provider)
        list.addView(user)
        list.addView(pass)
        list.addView(btn)

        btn.setOnClickListener {
            val providerCode = provider.text.toString().trim()
            val username = user.text.toString().trim()
            val password = pass.text.toString()
            if (providerCode.isBlank() || username.isBlank() || password.isBlank()) {
                status.text = "Preencha todos os campos"
                return@setOnClickListener
            }
            scope.launch {
                status.text = "Validando login…"
                btn.isEnabled = false
                runCatching {
                    ApiClient.service.login(
                        LoginRequest(
                            provider_code = providerCode,
                            username = username,
                            password = password,
                            device_id = deviceId,
                            device_code = deviceId.takeLast(6).uppercase()
                        )
                    ).body()
                }.onSuccess { res ->
                    if (res?.success == true && !res.token.isNullOrBlank()) {
                        token = res.token
                        getPreferences(MODE_PRIVATE).edit().putString("token", token).apply()
                        showHome()
                    } else {
                        status.text = res?.message ?: "Login não autorizado"
                        btn.isEnabled = true
                    }
                }.onFailure {
                    status.text = "Erro de conexão: ${it.message}"
                    btn.isEnabled = true
                }
            }
        }
        provider.requestFocus()
    }

    private fun showHome() {
        navStack.clear()
        list.removeAllViews()
        status.text = "Bem-vindo! Escolha uma área"

        val btnLive = button("📺  TV AO VIVO").apply { setOnClickListener { loadCategories("live") } }
        val btnMovies = button("🎬  FILMES").apply { setOnClickListener { loadCategories("vod") } }
        val btnSeries = button("🎞️  SÉRIES").apply { setOnClickListener { loadCategories("series") } }
        val btnLogout = button("⬅  SAIR / TROCAR CONTA").apply {
            setOnClickListener {
                getPreferences(MODE_PRIVATE).edit().clear().apply()
                token = ""
                showLogin()
            }
        }

        list.addView(btnLive)
        list.addView(btnMovies)
        list.addView(btnSeries)
        list.addView(space())
        list.addView(btnLogout)

        btnLive.requestFocus()
    }

    private fun loadCategories(type: String) {
        navStack.addLast { showHome() }
        scope.launch {
            status.text = "Carregando categorias…"
            list.removeAllViews()
            list.addView(loadingText())

            val res = runCatching {
                when (type) {
                    "live" -> ApiClient.service.liveCategories(token).body()
                    "vod" -> ApiClient.service.vodCategories(token).body()
                    else -> ApiClient.service.seriesCategories(token).body()
                }
            }.getOrNull()

            val cats = res?.categories ?: emptyList()
            list.removeAllViews()

            if (cats.isEmpty()) {
                status.text = "Nenhuma categoria encontrada"
                return@launch
            }

            val label = when (type) { "live" -> "TV AO VIVO" "vod" -> "FILMES" else -> "SÉRIES" }
            status.text = "$label — ${cats.size} categorias"

            cats.forEach { c ->
                list.addView(button(c.displayName()).apply {
                    setOnClickListener { loadItems(type, c.displayId()) }
                })
            }

            // Focus first item
            (list.getChildAt(0) as? Button)?.requestFocus()
        }
    }

    private fun loadItems(type: String, categoryId: String) {
        navStack.addLast { loadCategories(type) }
        scope.launch {
            status.text = "Carregando conteúdos…"
            list.removeAllViews()
            list.addView(loadingText())

            val res = runCatching {
                when (type) {
                    "live" -> ApiClient.service.liveStreams(token, categoryId).body()
                    "vod" -> ApiClient.service.vodMovies(token, categoryId).body()
                    else -> ApiClient.service.seriesList(token, categoryId).body()
                }
            }.getOrNull()

            val items = res?.streams ?: res?.movies ?: res?.series ?: emptyList()
            list.removeAllViews()

            if (items.isEmpty()) {
                status.text = "Nenhum item nesta categoria"
                return@launch
            }

            status.text = "${items.size} itens"
            items.forEach { item ->
                list.addView(button(item.displayTitle()).apply {
                    setOnClickListener { play(type, item) }
                })
            }
            (list.getChildAt(0) as? Button)?.requestFocus()
        }
    }

    private fun play(type: String, item: StreamItem) {
        scope.launch {
            status.text = "Preparando player…"

            // Tenta URL direta primeiro, senão consulta API de play
            val directUrl = item.directUrl()
            val url: String?

            if (!directUrl.isNullOrBlank()) {
                url = directUrl
            } else {
                val res = runCatching {
                    val id = item.itemId()
                    when (type) {
                        "live" -> ApiClient.service.playLive(token, id = id).body()
                        "vod" -> ApiClient.service.vodPlay(token, id).body()
                        else -> ApiClient.service.seriesPlay(token, id).body()
                    }
                }.getOrNull()
                url = res?.stream_url ?: res?.url ?: res?.play_url
            }

            if (url.isNullOrBlank()) {
                status.text = "URL não disponível para este conteúdo"
            } else {
                status.text = "Reproduzindo…"
                startActivity(
                    Intent(this@MainActivity, PlayerActivity::class.java)
                        .putExtra("url", url)
                        .putExtra("title", item.displayTitle())
                        .putExtra("type", type)
                )
            }
        }
    }

    // ── Navegação com controle remoto ────────────────────────────────────────

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (navStack.isNotEmpty()) {
                navStack.removeLast().invoke()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ── Helpers de UI ────────────────────────────────────────────────────────

    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint
        textSize = 20f
        setSingleLine(true)
        setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFFAAAAAA.toInt())
        setPadding(20, 18, 20, 18)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 8, 0, 8)
        layoutParams = lp
    }

    private fun button(label: String) = Button(this).apply {
        text = label
        textSize = 18f
        gravity = Gravity.CENTER_VERTICAL or Gravity.START
        setPadding(30, 0, 30, 0)
        isFocusable = true
        isFocusableInTouchMode = true
        minHeight = 72
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundResource(android.R.drawable.list_selector_background)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 4, 0, 4)
        layoutParams = lp
    }

    private fun loadingText() = TextView(this).apply {
        text = "⏳ Carregando…"
        textSize = 18f
        setTextColor(0xFFCCCCCC.toInt())
        setPadding(30, 20, 30, 20)
    }

    private fun space() = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(-1, 30)
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
