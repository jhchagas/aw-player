package com.syntra.rokuport.ui

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var errorText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Fullscreen
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        val url = intent.getStringExtra("url") ?: run { finish(); return }
        val title = intent.getStringExtra("title") ?: ""

        val root = FrameLayout(this)

        playerView = PlayerView(this).apply {
            useController = true
            keepScreenOn = true
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        errorText = TextView(this).apply {
            textSize = 18f
            setTextColor(0xFFFF4444.toInt())
            visibility = View.GONE
            setPadding(40, 40, 40, 40)
        }
        root.addView(errorText, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = android.view.Gravity.CENTER
        })

        setContentView(root)

        initPlayer(url, title)
    }

    private fun initPlayer(url: String, title: String) {
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo

            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    errorText.text = "Erro ao reproduzir:\n${error.message}\n\nURL: $url"
                    errorText.visibility = View.VISIBLE
                }
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) errorText.visibility = View.GONE
                }
            })

            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                player?.stop()
                finish()
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_DPAD_CENTER -> {
                player?.let {
                    if (it.isPlaying) it.pause() else it.play()
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                player?.let { it.seekTo(it.currentPosition + 10_000) }
                true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_DPAD_LEFT -> {
                player?.let { it.seekTo(maxOf(0, it.currentPosition - 10_000)) }
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
