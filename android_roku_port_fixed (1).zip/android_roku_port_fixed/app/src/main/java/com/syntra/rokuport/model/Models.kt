package com.syntra.rokuport.model

import com.google.gson.annotations.SerializedName

// ── Requests ────────────────────────────────────────────────────────────────

data class RegisterRequest(
    val device_id: String,
    val device_model: String = "Android TV",
    val app_version: String = "1.0.0"
)

data class CheckRequest(
    val device_id: String,
    val activation_code: String
)

data class LoginRequest(
    val provider_code: String,
    val username: String,
    val password: String,
    val device_id: String,
    val device_code: String,
    val device_name: String = "Android TV",
    val app_version: String = "1.0.0"
)

// ── Responses ────────────────────────────────────────────────────────────────

data class ApiResponse(
    val success: Boolean? = null,
    val message: String? = null,
    val token: String? = null,
    val activation_code: String? = null,
    val device_code: String? = null,
    val data: Any? = null,
    val categories: List<Category>? = null,
    val streams: List<StreamItem>? = null,
    val movies: List<StreamItem>? = null,
    val series: List<StreamItem>? = null,
    val stream_url: String? = null,
    val url: String? = null,
    val play_url: String? = null
)

data class Category(
    @SerializedName("category_id") val categoryId: String? = null,
    val id: String? = null,
    @SerializedName("category_name") val categoryName: String? = null,
    val name: String? = null,
    @SerializedName("streams_count") val streamsCount: Int? = null
) {
    fun displayId() = categoryId ?: id ?: ""
    fun displayName() = categoryName ?: name ?: "Sem nome"
}

data class StreamItem(
    @SerializedName("stream_id") val streamId: String? = null,
    val id: String? = null,
    val num: Int? = null,
    val name: String? = null,
    val title: String? = null,
    @SerializedName("stream_display_name") val streamDisplayName: String? = null,
    @SerializedName("stream_icon") val streamIcon: String? = null,
    val cover: String? = null,
    val image: String? = null,
    @SerializedName("stream_url") val streamUrl: String? = null,
    val url: String? = null,
    @SerializedName("play_url") val playUrl: String? = null
) {
    fun displayTitle() = streamDisplayName ?: name ?: title ?: "Sem título"
    fun itemId() = streamId ?: id ?: num?.toString() ?: ""
    fun poster() = streamIcon ?: cover ?: image
    fun directUrl() = streamUrl ?: url ?: playUrl
}
