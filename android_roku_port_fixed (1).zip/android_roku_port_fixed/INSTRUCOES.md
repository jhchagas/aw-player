# AW Player Android TV — Instruções de Compilação e Instalação

## ✅ Pré-requisitos

| Ferramenta | Versão mínima | Download |
|---|---|---|
| Android Studio | Hedgehog 2023.1+ | https://developer.android.com/studio |
| Java (JDK) | 17+ | Incluso no Android Studio |
| Android SDK | API 35 | Instalar via Android Studio |

---

## ⚙️ 1. Configure a URL da sua API

Abra o arquivo:
```
app/src/main/java/com/syntra/rokuport/api/ApiClient.kt
```

Localize a linha:
```kotlin
const val API_BASE = "https://seuip-ou-url/"
```

Substitua pela URL real do seu painel IPTV, **com barra no final**:
```kotlin
const val API_BASE = "https://seudominio.com/"
// ou
const val API_BASE = "http://123.456.789.0:8080/"
```

> ⚠️ Se a URL usar HTTP (não HTTPS), o `android:usesCleartextTraffic="true"` já está ativo no Manifest.

---

## 🔨 2. Compilar o APK

### Pelo Android Studio (recomendado):
1. Abra o Android Studio → **File → Open** → selecione a pasta `android_roku_port`
2. Aguarde o Gradle sync
3. Para APK de teste: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. O APK gerado fica em: `app/build/outputs/apk/debug/app-debug.apk`

### Pela linha de comando:
```bash
# Linux/Mac
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

APK de release (assinado):
```bash
./gradlew assembleRelease
```

---

## 📲 3. Instalar na TV Box / Android TV

### Via ADB (cabo USB ou rede):
```bash
# Conectar via rede (habilitar Depuração ADB nas configurações da TV)
adb connect IP_DA_TV:5555

# Instalar
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Via pen drive / gerenciador de arquivos:
1. Copie o APK para um pen drive
2. Conecte na TV Box
3. Abra um gerenciador de arquivos (ES File Explorer, etc.)
4. Navegue até o APK e instale

### Via Downloader (Fire TV / Android TV):
1. Instale o app "Downloader" na TV
2. Transfira o APK para um servidor/link público
3. Acesse pelo Downloader

---

## 📋 4. Funcionalidades do App

| Tela | Função |
|---|---|
| **Splash** | Tela de abertura com logo |
| **Login** | Código do provedor + usuário + senha |
| **Home** | Menu: TV ao Vivo / Filmes / Séries |
| **Categorias** | Lista de categorias da API |
| **Conteúdos** | Lista de canais/filmes/séries |
| **Player** | ExoPlayer (Media3) com suporte HLS/MP4/RTMP |

### Controle remoto:
- **OK / Enter** → selecionar / play/pause
- **Voltar** → navegar para a tela anterior
- **Seta Direita** → avançar 10s no player
- **Seta Esquerda** → voltar 10s no player

---

## 🛠️ 5. Estrutura de arquivos importantes

```
app/src/main/java/com/syntra/rokuport/
├── api/
│   ├── ApiClient.kt       ← URL da API aqui
│   └── RokuApi.kt         ← Endpoints da API
├── model/
│   └── Models.kt          ← Estrutura de dados
├── ui/
│   ├── SplashActivity.kt  ← Tela de abertura
│   ├── MainActivity.kt    ← Navegação principal
│   └── PlayerActivity.kt  ← Player de vídeo
└── App.kt
```

---

## ❓ Problemas comuns

| Erro | Solução |
|---|---|
| `CLEARTEXT not permitted` | Verifique se `usesCleartextTraffic="true"` está no Manifest |
| `Login não autorizado` | Confirme a URL da API e as credenciais |
| `URL não disponível` | A API não retornou stream_url; verifique os logs |
| Player não reproduz HLS | Media3 com `exoplayer-hls` já está incluído |
| APK não instala na TV | Habilite "Fontes desconhecidas" nas configurações |
