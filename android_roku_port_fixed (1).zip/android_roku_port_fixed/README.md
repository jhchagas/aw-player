# Syntra Roku Port Android TV

Base inicial Android TV criada a partir do source Roku enviado.

## O que foi reaproveitado
- Assets: logo, splash, fundo e ícones.
- Fluxo: login -> home -> categorias -> itens -> player.
- Endpoints encontrados no Roku:
  - POST /api/roku/register.php
  - POST /api/roku/check-activation.php
  - POST /api/roku/login.php
  - GET /api/roku/home.php?token=
  - GET /api/roku/live-categories.php?token=
  - GET /api/roku/live-streams.php?token=&category_id=
  - GET /api/roku/play.php?token=&type=live&id=&ext=m3u8
  - GET /api/roku/vod-categories.php?token=
  - GET /api/roku/vod-movies.php?token=&category_id=
  - GET /api/roku/vod-play.php?token=&id=
  - GET /api/roku/series-categories.php?token=
  - GET /api/roku/series-list.php?token=&category_id=
  - GET /api/roku/series-info.php?token=&series_id=
  - GET /api/roku/series-play.php?token=&episode_id=

## Antes de compilar
Abra `app/src/main/java/com/syntra/rokuport/api/ApiClient.kt` e troque:

```kotlin
const val API_BASE = "https://seuip-ou-url/"
```

pela URL real do painel, sempre com `/` no final.

## Como compilar
1. Abra a pasta no Android Studio.
2. Aguarde sincronizar o Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Observação
Esta é uma base inicial. Pode precisar ajustar os nomes dos campos JSON conforme a resposta real do seu painel.
